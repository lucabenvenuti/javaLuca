package patterns.visitor;

interface Visitor<T> {
	T visitWheel(Wheel wheel);

	T visitEngine(Engine engine);

	T visitBody(Body body);

	T visitCar(Car car);

	T visitZylinder(Zylinder zylinder);

	T visitSchneeschaufel(Schneeschaufel schneeschaufel);
}

class WeightVisitor implements Visitor<Integer> {

	@Override
	public Integer visitWheel(Wheel wheel) {
		return wheel.getWeight();
	}

	@Override
	public Integer visitEngine(Engine engine) {
		int zylinder = visitZylinder(engine.zylinder);
		return engine.getWeight() + zylinder;
	}

	@Override
	public Integer visitBody(Body body) {
		return body.getWeight();
	}

	@Override
	public Integer visitCar(Car car) {
		int body = car.body.accept(this);
		int wheels = 0;
		for (int i = 0; i < car.wheels.length; ++i)
			wheels += car.wheels[i].accept(this);
		int engine = car.engine.accept(this);
		int schneeschaufel = car.schnee.accept(this);
		return body + wheels + engine + schneeschaufel;
	}

	@Override
	public Integer visitZylinder(Zylinder zylinder) {
		return zylinder.getWeight();
	}

	@Override
	public Integer visitSchneeschaufel(Schneeschaufel schneeschaufel) {
		return schneeschaufel.getWeight();
	}

}

public class VisitorDemo {
	static public void main(String[] args) {
		Car car = new Car();

		Visitor<Integer> drawVisitor = new WeightVisitor();
		System.out.println(car.accept(drawVisitor));
	}
}
