package patterns.visitor;

class Wheel {

	private String name;
	private final int weight = 1;

	Wheel(String name) {
		this.name = name;
	}

	public int getWeight() {
		return weight;
	}

	String getName() {
		return this.name;
	}

	<T> T accept(Visitor<T> visitor) {
		return visitor.visitWheel(this);
	}
}

class Engine {
	Zylinder zylinder;

	private final int weight = 5;

	public Engine(Zylinder zylinder) {
		this.zylinder = zylinder;
	}

	public int getWeight() {
		return weight;
	}

	<T> T accept(Visitor<T> visitor) {
		return visitor.visitEngine(this);
	}
}

class Zylinder {

	private final int weight = 2;

	public int getWeight() {
		return weight;
	}

	<T> T accept(Visitor<T> visitor) {
		return visitor.visitZylinder(this);
	}
}

class Body {

	private final int weight = 6;

	public int getWeight() {
		return weight;
	}

	<T> T accept(Visitor<T> visitor) {
		return visitor.visitBody(this);
	}

}

class Schneeschaufel {

	private final int weight = 2;

	public int getWeight() {
		return weight;
	}

	<T> T accept(Visitor<T> visitor) {
		return visitor.visitSchneeschaufel(this);
	}
}

public class Car {
	Schneeschaufel schnee = new Schneeschaufel();
	Engine engine = new Engine(new Zylinder());
	Body body = new Body();
	Wheel[] wheels = { new Wheel("front left"), new Wheel("front right"),
			new Wheel("back left"), new Wheel("back right") };

	<T> T accept(Visitor<T> visitor) {
		return visitor.visitCar(this);
	}
}
